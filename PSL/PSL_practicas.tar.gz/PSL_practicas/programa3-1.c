#include <sys/types.h>
#include <stdio.h>

main()
{
   printf("Identificador de usuario: %d\n", getuid());
}

