#include <stdlib.h>

struct Timeval
{
    time_t tv_sec;
    suseconds_t tv_usec;
};
