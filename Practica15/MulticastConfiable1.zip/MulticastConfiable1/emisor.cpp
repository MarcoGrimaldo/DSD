#include "SocketMulticast.h"

int main(int argc, char* argv[])
{

	if(argc!= 6){
        cout << "Error: MODO de uso <IP> <Puerto> <TTL> <Cadena entre comillas> <Numero de receptores>" << endl;
        exit(1);
    }
    
    char* IP = argv[1];
    int puerto = atoi(argv[2]);
    int TTL = atoi(argv[3]);
    char* Cadena = argv[4];
    int num_receptores = atoi(argv[5]);

	/*if (argc != 4)
	{
		printf("Forma de uso: %s ip_emisor n num_receptores\n", argv[0]);
		exit(0);
	}
	srand(time(NULL));
	int n = atoi(argv[2]);
	int cont = 0;
	int cuenta = 0;
	int num_receptores = atoi(argv[3]);*/
	

	SocketDatagrama s = SocketDatagrama(puerto);
	SocketMulticast sm = SocketMulticast(0);

	//while (cont < n)
	//{
	//	int arr = 1 + rand() % 9;
	//	cuenta = cuenta + arr;
    	PaqueteDatagrama p = PaqueteDatagrama(Cadena, sizeof(Cadena), IP, 3030);
    	int enviar = sm.enviaConfiable(p, TTL, num_receptores);
    	int intentos = 1;

		while(enviar < 0 && intentos < 7) {
			cout << "Reintentando" << endl;
			enviar = sm.enviaConfiable(p, TTL, num_receptores);
			intentos++;
		}

		if(intentos == 7){
			cout << "Algun receptor no da respuesta" << endl;
			exit(0);
		}
		
		//printf("Num: %d\nOriginal: %d\n", arr, cuenta);
		
		int cont2 = 0;
		while(cont2 < num_receptores) {
			PaqueteDatagrama respuesta = PaqueteDatagrama(4);
	        s.recibeTimeout(respuesta, 5, 500);
	        //int res = 0;
	        //memcpy(&res, respuesta.obtieneDatos(), 4);
			/*if (cuenta != res)
			{
				printf("Respuesta receptor %d: %d  ip: ", cont2 + 1, res);
				cout<< respuesta.obtieneDireccion()<<endl;
				//exit(0);
			}*/
			printf("Respuesta del receptor %d: %s | IP:", cont2 + 1,respuesta.obtieneDatos());
			cout<< respuesta.obtieneDireccion()<<endl;
			cont2++;
		}
		
	    //cont++;
	//}
	return 0;
}